﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ludoop.Backend
{
    interface IPiece : IMove
    {
        
    }
}
