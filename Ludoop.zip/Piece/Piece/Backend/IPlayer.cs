﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ludoop.Backend
{
    public interface IPlayer : IName, ITeam
    {

    }
}
