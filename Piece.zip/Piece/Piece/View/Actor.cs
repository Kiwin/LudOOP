﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ludoop.View
{
    public abstract class Actor
    {
        public abstract void Draw(float x, float y, float w, float h);

    }
}
