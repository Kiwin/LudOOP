﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ludoop.View
{
    public interface IDraw
    {

        Actor Actor{
            get;
            set;
        }
    }
}
